# CheeseCam — Cloud Build

This project contains a GitHub Actions workflow that builds the Android APK in the cloud.

After pushing the project to GitHub:
1. Open the **Actions** tab.
2. Choose **Build CheeseCam APK**.
3. Tap **Run workflow** if needed.
4. Open the completed run.
5. Under **Artifacts**, download **CheeseCam-debug-apk**.
6. Extract the artifact and install the `.apk` on Android.

The debug APK is unsigned for Play Store distribution, but is suitable for direct installation on a test device after enabling installation from the source you used (browser/files).
