# CheeseCam 1.5 Release Candidate Checklist

## Two-device acceptance test
- [ ] Install the same APK on two Android phones.
- [ ] Phone A selects Camera.
- [ ] Phone B selects Remote.
- [ ] Both grant required nearby/camera permissions.
- [ ] A advertises and B discovers.
- [ ] Connection becomes Connected on both.
- [ ] Camera preview remains smooth locally.
- [ ] Remote receives preview frames continuously.
- [ ] Remote shutter causes a full-resolution photo on Camera.
- [ ] Photo appears in Pictures/CheeseCam.
- [ ] Flash command works.
- [ ] Zoom command works.
- [ ] Timer command works.
- [ ] Disconnect stops the preview stream.
- [ ] Reconnect starts a fresh stream.
- [ ] App survives screen rotation/recreation where supported.

## Important
This repository is a release candidate source project, not a claim that a physical two-device test has been performed in this environment.
