@echo off
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 ( gradle %* & exit /b %ERRORLEVEL% )
echo Please use Gradle 8.13 or run gradlew on Linux.
exit /b 1
