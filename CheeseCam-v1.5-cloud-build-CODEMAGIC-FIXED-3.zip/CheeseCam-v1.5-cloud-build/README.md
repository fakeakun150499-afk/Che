# CheeseCam v1.0.0

Versi ini menaikkan prototype menjadi fondasi aplikasi remote-camera nyata:

- CameraX untuk preview dan foto.
- Foto disimpan ke `Pictures/CheeseCam`.
- Flash dan kualitas foto.
- Nearby Connections P2P untuk koneksi satu kamera ↔ satu remote.
- Perintah `SHUTTER` dari remote ke kamera.
- Tombol "Jadikan Kamera" dan "Cari Kamera".

## Tahap berikutnya untuk release penuh
1. Streaming preview kamera ke remote secara realtime.
2. QR/pairing code dan verifikasi koneksi.
3. Remote zoom/flash/camera switch.
4. Timer 3/5/10 detik.
5. Video capture.
6. Reconnect otomatis dan indikator kualitas koneksi.
7. Pengujian lintas perangkat Android.

Arsitektur ini menggunakan CameraX dan Nearby Connections, yang memang menyediakan API resmi Android untuk capture kamera dan komunikasi perangkat terdekat tanpa internet.

## v1.1 live preview layer
The project now includes a CameraX ImageAnalysis-based preview producer and a Nearby byte-frame receiver. The pipeline intentionally uses latest-frame behavior and moderate JPEG compression as a baseline; production quality should move to a codec/stream transport after device testing.

## v1.2
Ditambahkan protokol kontrol remote yang terversi untuk shutter, flash, kamera depan/belakang, zoom, dan timer, serta komponen UI kontrol remote. CameraX dinaikkan ke 1.6.x agar jalur pengembangan mengikuti dokumentasi CameraX terbaru.

## v1.3
Added a framed continuous preview stream over Nearby Connections. Camera-side frames can be written into a `Payload.Type.STREAM`, and the remote reconstructs JPEG frame boundaries using a small CCP1 framing protocol. Control messages remain `BYTES`.

## v1.4 integrated foundation
CameraX Preview + ImageAnalysis are now bound together, the remote can decode received JPEG preview frames, and the Nearby connection lifecycle is surfaced to the UI. The final production step is wiring a single long-lived `Payload.Type.STREAM` to the connected endpoint and adding device-level integration tests; Nearby documents that stream payloads should be read continuously on a background thread and closed when the transfer stops.

## v1.5 Release Candidate
The project now has a persistent preview stream abstraction, command dispatch, disconnect cleanup, and a physical two-device acceptance checklist. The remaining gate is building the APK and running that checklist on real Android devices.

## Cloud build
This repository includes `.github/workflows/build-apk.yml` to compile a debug APK using GitHub Actions. The resulting APK is a test build; physical two-device validation is still required.
