package com.sanglakon.cheesecam

import com.google.android.gms.nearby.connection.Payload
import java.io.PipedInputStream
import java.io.PipedOutputStream
import java.util.concurrent.atomic.AtomicBoolean

class PersistentPreviewStream(
    private val send: (Payload) -> Unit
) {
    private var input: PipedInputStream? = null
    private var output: PipedOutputStream? = null
    private val active = AtomicBoolean(false)

    @Synchronized
    fun start() {
        if (!active.compareAndSet(false, true)) return
        val inputStream = PipedInputStream(256 * 1024)
        val outputStream = PipedOutputStream(inputStream)
        input = inputStream
        output = outputStream
        send(Payload.fromStream(inputStream))
    }

    fun write(frame: ByteArray) {
        if (!active.get()) return
        try {
            PreviewStreamProtocol.writeFrame(output ?: return, frame)
        } catch (_: Exception) {
            stop()
        }
    }

    @Synchronized
    fun stop() {
        if (!active.getAndSet(false)) return
        try { output?.close() } catch (_: Exception) {}
        try { input?.close() } catch (_: Exception) {}
        output = null
        input = null
    }
}
