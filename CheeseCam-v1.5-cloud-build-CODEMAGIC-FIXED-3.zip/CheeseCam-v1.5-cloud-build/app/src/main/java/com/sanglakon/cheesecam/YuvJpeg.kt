package com.sanglakon.cheesecam

import android.graphics.ImageFormat
import android.graphics.Rect
import android.graphics.YuvImage
import androidx.camera.core.ImageProxy
import java.io.ByteArrayOutputStream

object YuvJpeg {
    fun encode(image: ImageProxy, quality: Int): ByteArray? {
        if (image.format != ImageFormat.YUV_420_888) return null
        val y = image.planes[0].buffer
        val u = image.planes[1].buffer
        val v = image.planes[2].buffer
        val yBytes = ByteArray(y.remaining()).also { y.get(it) }
        val uBytes = ByteArray(u.remaining()).also { u.get(it) }
        val vBytes = ByteArray(v.remaining()).also { v.get(it) }

        val nv21 = ByteArray(yBytes.size + uBytes.size + vBytes.size)
        System.arraycopy(yBytes, 0, nv21, 0, yBytes.size)
        var p = yBytes.size
        var i = 0
        while (i < minOf(uBytes.size, vBytes.size)) {
            nv21[p++] = vBytes[i]
            nv21[p++] = uBytes[i]
            i++
        }
        val out = ByteArrayOutputStream()
        YuvImage(nv21, ImageFormat.NV21, image.width, image.height, null)
            .compressToJpeg(Rect(0, 0, image.width, image.height), quality, out)
        return out.toByteArray()
    }
}
