package com.sanglakon.cheesecam

import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.InputStream
import java.io.OutputStream

object PreviewStreamProtocol {
    private const val MAGIC = 0x43435031 // "CCP1"
    private const val MAX_FRAME = 1_500_000

    fun writeFrame(out: OutputStream, jpeg: ByteArray) {
        require(jpeg.size <= MAX_FRAME)
        val data = DataOutputStream(out)
        data.writeInt(MAGIC)
        data.writeInt(jpeg.size)
        data.write(jpeg)
        data.flush()
    }

    fun readFrame(input: InputStream): ByteArray? {
        val data = DataInputStream(input)
        val magic = try { data.readInt() } catch (_: Exception) { return null }
        if (magic != MAGIC) return null
        val size = data.readInt()
        if (size <= 0 || size > MAX_FRAME) return null
        val frame = ByteArray(size)
        data.readFully(frame)
        return frame
    }
}
