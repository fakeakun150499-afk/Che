package com.sanglakon.cheesecam

import com.google.android.gms.nearby.connection.Payload
import java.io.InputStream
import java.util.concurrent.atomic.AtomicBoolean

class PreviewStreamReceiver {
    private val running = AtomicBoolean(false)

    fun start(payload: Payload, onFrame: (ByteArray) -> Unit) {
        if (!running.compareAndSet(false, true)) {
            payload.close()
            return
        }
        val input: InputStream = payload.asStream().asInputStream()
        Thread {
            input.use {
                while (running.get()) {
                    val frame = PreviewStreamProtocol.readFrame(it) ?: break
                    onFrame(frame)
                }
            }
            payload.close()
            running.set(false)
        }.start()
    }

    fun stop() {
        running.set(false)
    }
}
