package com.sanglakon.cheesecam

import android.graphics.ImageFormat
import android.graphics.Rect
import android.graphics.YuvImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.android.gms.nearby.connection.Payload
import java.io.ByteArrayOutputStream
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Camera-side preview producer.
 *
 * Frames are deliberately bounded and latest-frame-wins to prevent the preview
 * transport from building an unbounded queue when the connection is slower
 * than the camera.
 */
class LivePreviewStreamer(
    private val send: (Payload) -> Unit
) {
    private val running = AtomicBoolean(false)

    fun analyzer(): ImageAnalysis.Analyzer = ImageAnalysis.Analyzer { image ->
        if (!running.get()) {
            image.close()
            return@Analyzer
        }
        try {
            val jpeg = yuv420ToJpeg(image, 55)
            if (jpeg != null) {
                send(Payload.fromBytes(jpeg))
            }
        } finally {
            image.close()
        }
    }

    fun start() { running.set(true) }
    fun stop() { running.set(false) }

    private fun yuv420ToJpeg(image: ImageProxy, quality: Int): ByteArray? {
        if (image.format != ImageFormat.YUV_420_888) return null
        val y = image.planes[0].buffer
        val u = image.planes[1].buffer
        val v = image.planes[2].buffer
        val ySize = y.remaining()
        val uSize = u.remaining()
        val vSize = v.remaining()
        val nv21 = ByteArray(ySize + uSize + vSize)
        y.get(nv21, 0, ySize)

        // NV21 expects V then U. Plane buffers can have row/pixel strides, so
        // this compact conversion is best treated as a baseline implementation.
        val uBytes = ByteArray(uSize)
        val vBytes = ByteArray(vSize)
        u.get(uBytes); v.get(vBytes)
        var p = ySize
        var i = 0
        while (i < minOf(vSize, uSize)) {
            nv21[p++] = vBytes[i]
            nv21[p++] = uBytes[i]
            i++
        }

        val out = ByteArrayOutputStream()
        val crop = Rect(0, 0, image.width, image.height)
        YuvImage(nv21, ImageFormat.NV21, image.width, image.height, null)
            .compressToJpeg(crop, quality, out)
        return out.toByteArray()
    }
}
