package com.sanglakon.cheesecam

import android.Manifest
import android.graphics.BitmapFactory
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import androidx.camera.view.PreviewView
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import android.content.pm.PackageManager

class MainActivity : ComponentActivity() {
    private lateinit var camera: CameraController
    private lateinit var nearby: NearbyRemote
    private val permissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        camera = CameraController(this)
        nearby = NearbyRemote(this)
        permissions.launch(arrayOf(
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.BLUETOOTH_ADVERTISE,
            Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.NEARBY_WIFI_DEVICES
        ))

        setContent {
            var cameraMode by remember { mutableStateOf(true) }
            var status by remember { mutableStateOf("Belum terhubung") }
            var latest by remember { mutableStateOf<androidx.compose.ui.graphics.ImageBitmap?>(null) }

            LaunchedEffect(Unit) {
                nearby.onConnectionChanged = { connected ->
                    runOnUiThread { status = if (connected) "Terhubung" else "Terputus" }
                }
                nearby.onPreviewFrame = { bytes ->
                    val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    if (bmp != null) runOnUiThread { latest = bmp.asImageBitmap() }
                }
            }

            MaterialTheme {
                Column(Modifier.fillMaxSize().background(Color.Black)) {
                    Row(
                        Modifier.fillMaxWidth().padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("CheeseCam", color = Color.White)
                        Text(status, color = Color.White)
                    }

                    Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        if (cameraMode) {
                            AndroidView(
                                factory = { PreviewView(it) },
                                modifier = Modifier.fillMaxSize(),
                                update = { view ->
                                    if (ContextCompat.checkSelfPermission(
                                            this, Manifest.permission.CAMERA
                                        ) == PackageManager.PERMISSION_GRANTED) {
                                        camera.start(this, view) { frame ->
                                            // Stream transport can be attached here once
                                            // the endpoint has been negotiated.
                                        }
                                    }
                                }
                            )
                        } else {
                            latest?.let { Image(it, null, Modifier.fillMaxSize()) }
                                ?: Text("Menunggu preview…", color = Color.White)
                        }
                    }

                    Row(
                        Modifier.fillMaxWidth().padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        Button(onClick = {
                            cameraMode = true
                            nearby.advertise().addOnSuccessListener { status = "Menunggu remote…" }
                        }) { Text("Kamera") }

                        Button(onClick = {
                            cameraMode = false
                            nearby.discover().addOnSuccessListener { status = "Mencari kamera…" }
                        }) { Text("Remote") }

                        Button(onClick = {
                            if (cameraMode) camera.takePhoto { ok ->
                                status = if (ok) "Foto tersimpan" else "Gagal"
                            } else {
                                nearby.sendCommand(RemoteProtocol.SHUTTER)
                                status = "Shutter dikirim"
                            }
                        }) { Text("📸") }
                    }
                    Spacer(Modifier.height(12.dp))
                }
            }
        }
    }

    override fun onDestroy() {
        nearby.stop()
        camera.stop()
        super.onDestroy()
    }
}
