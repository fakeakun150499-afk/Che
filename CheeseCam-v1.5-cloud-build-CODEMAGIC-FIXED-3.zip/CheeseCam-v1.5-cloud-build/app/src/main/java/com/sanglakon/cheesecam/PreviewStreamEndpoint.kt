package com.sanglakon.cheesecam

import com.google.android.gms.nearby.connection.Nearby
import com.google.android.gms.nearby.connection.Payload
import java.io.PipedInputStream
import java.io.PipedOutputStream
import java.util.concurrent.atomic.AtomicBoolean

class PreviewStreamEndpoint(
    private val sendPayload: (Payload) -> Unit
) {
    private var pipeOut: PipedOutputStream? = null
    private var running = AtomicBoolean(false)

    fun start() {
        if (!running.compareAndSet(false, true)) return
        val input = PipedInputStream(64 * 1024)
        val output = PipedOutputStream(input)
        pipeOut = output
        sendPayload(Payload.fromStream(input))
    }

    fun sendJpeg(frame: ByteArray) {
        if (!running.get()) return
        try {
            PreviewStreamProtocol.writeFrame(pipeOut ?: return, frame)
        } catch (_: Exception) {
            stop()
        }
    }

    fun stop() {
        running.set(false)
        try { pipeOut?.close() } catch (_: Exception) {}
        pipeOut = null
    }
}
