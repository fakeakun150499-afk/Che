package com.sanglakon.cheesecam

/**
 * Small, versioned command protocol shared by camera and remote.
 * Keeping commands explicit makes it possible to evolve the wire format
 * without breaking older clients.
 */
object RemoteProtocol {
    const val VERSION = 1

    const val SHUTTER = "v1|SHUTTER"
    const val FLASH_ON = "v1|FLASH|1"
    const val FLASH_OFF = "v1|FLASH|0"
    const val FRONT = "v1|CAMERA|FRONT"
    const val BACK = "v1|CAMERA|BACK"

    fun zoom(ratio: Float) = "v1|ZOOM|${"%.2f".format(java.util.Locale.US, ratio)}"
    fun timer(seconds: Int) = "v1|TIMER|$seconds"
}
