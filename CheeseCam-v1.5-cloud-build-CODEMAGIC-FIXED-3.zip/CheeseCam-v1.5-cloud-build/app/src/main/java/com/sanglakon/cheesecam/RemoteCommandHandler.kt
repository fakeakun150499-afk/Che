package com.sanglakon.cheesecam

class RemoteCommandHandler(
    private val camera: CameraController
) {
    fun handle(command: String) {
        when {
            command == RemoteProtocol.SHUTTER -> camera.takePhoto { }
            command == RemoteProtocol.FLASH_ON -> camera.setFlash(true)
            command == RemoteProtocol.FLASH_OFF -> camera.setFlash(false)
            command == RemoteProtocol.FRONT -> camera.switchCamera()
            command == RemoteProtocol.BACK -> camera.switchCamera()
            command.startsWith("v1|ZOOM|") ->
                command.substringAfterLast("|").toFloatOrNull()?.let(camera::setZoom)
            command.startsWith("v1|TIMER|") ->
                command.substringAfterLast("|").toIntOrNull()?.let { seconds ->
                    if (seconds <= 0) camera.takePhoto { }
                    else camera.takePhotoAfter(seconds)
                }
        }
    }
}
