package com.sanglakon.cheesecam

import android.content.Context
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.*
import com.google.android.gms.tasks.Task

class NearbyRemote(private val context: Context) {
    private val client = Nearby.getConnectionsClient(context)
    private val serviceId = context.packageName
    private val strategy = Strategy.P2P_POINT_TO_POINT

    var connectedEndpoint: String? = null
        private set

    var onPreviewFrame: ((ByteArray) -> Unit)? = null
    var onConnectionChanged: ((Boolean) -> Unit)? = null
    var onCommand: ((String) -> Unit)? = null
    private var previewStream: PreviewStreamReceiver? = null

    private val lifecycle = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(id: String, info: ConnectionInfo) {
            client.acceptConnection(id, payloadCallback)
        }
        override fun onConnectionResult(id: String, result: ConnectionResolution) {
            if (result.status.isSuccess) { connectedEndpoint = id; onConnectionChanged?.invoke(true) }
        }
        override fun onDisconnected(id: String) {
            if (connectedEndpoint == id) { connectedEndpoint = null; onConnectionChanged?.invoke(false) }
        }
    }

    private val discovery = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(id: String, info: DiscoveredEndpointInfo) {
            client.requestConnection("CheeseCam", id, lifecycle)
        }
        override fun onEndpointLost(id: String) {}
    }

    private val payloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(id: String, payload: Payload) {
            if (payload.type == Payload.Type.STREAM) {
                val receiver = PreviewStreamReceiver()
                previewStream = receiver
                receiver.start(payload) { frame -> onPreviewFrame?.invoke(frame) }
            } else if (payload.type == Payload.Type.BYTES) {
                val bytes = payload.asBytes() ?: return
                val command = bytes.toString(Charsets.UTF_8)
                onCommand?.invoke(command)
            }
        }
        override fun onPayloadTransferUpdate(id: String, update: PayloadTransferUpdate) {}
    }

    fun advertise(): Task<Void> =
        client.startAdvertising(
            "CheeseCam",
            serviceId,
            lifecycle,
            AdvertisingOptions.Builder().setStrategy(strategy).build()
        )

    fun discover(): Task<Void> =
        client.startDiscovery(
            serviceId,
            discovery,
            DiscoveryOptions.Builder().setStrategy(strategy).build()
        )

    fun sendCommand(command: String): Task<Void>? {
        val id = connectedEndpoint ?: return null
        return client.sendPayload(id, Payload.fromBytes(command.toByteArray()))
    }

    fun stop() {
        client.stopAdvertising()
        client.stopDiscovery()
        previewStream?.stop()
        previewStream = null
        client.stopAllEndpoints()
        connectedEndpoint = null
    }
}
