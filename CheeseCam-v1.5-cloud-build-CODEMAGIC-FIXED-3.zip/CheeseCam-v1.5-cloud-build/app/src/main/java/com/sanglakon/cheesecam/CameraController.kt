package com.sanglakon.cheesecam

import android.content.ContentValues
import android.content.Context
import android.provider.MediaStore
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class CameraController(private val context: Context) {
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var analysis: ImageAnalysis? = null
    private var front = false
    private val executor: ExecutorService = Executors.newSingleThreadExecutor()

    fun start(
        owner: LifecycleOwner,
        previewView: PreviewView,
        onPreviewJpeg: ((ByteArray) -> Unit)? = null
    ) {
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            val provider = future.get()
            val selector = if (front) CameraSelector.DEFAULT_FRONT_CAMERA
            else CameraSelector.DEFAULT_BACK_CAMERA

            val preview = Preview.Builder().build().also {
                it.surfaceProvider = previewView.surfaceProvider
            }

            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .build()

            analysis = ImageAnalysis.Builder()
                .setTargetResolution(android.util.Size(640, 360))
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()

            analysis?.setAnalyzer(executor) { image ->
                try {
                    if (onPreviewJpeg != null) {
                        val jpeg = YuvJpeg.encode(image, 55)
                        if (jpeg != null) onPreviewJpeg(jpeg)
                    }
                } finally {
                    image.close()
                }
            }

            provider.unbindAll()
            camera = provider.bindToLifecycle(owner, selector, preview, imageCapture, analysis)
        }, ContextCompat.getMainExecutor(context))
    }

    fun takePhoto(onDone: (Boolean) -> Unit) {
        val capture = imageCapture ?: return onDone(false)
        val name = "CheeseCam_" +
            SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".jpg"
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/CheeseCam")
        }
        val output = ImageCapture.OutputFileOptions.Builder(
            context.contentResolver,
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            values
        ).build()
        capture.takePicture(
            output,
            ContextCompat.getMainExecutor(context),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(result: ImageCapture.OutputFileResults) = onDone(true)
                override fun onError(exception: ImageCaptureException) = onDone(false)
            }
        )
    }

    fun setFlash(on: Boolean) {
        imageCapture?.flashMode =
            if (on) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF
    }

    fun setZoom(ratio: Float) {
        camera?.cameraControl?.setZoomRatio(ratio.coerceAtLeast(1f))
    }

    fun switchCamera() {
        front = !front
    }

    fun takePhotoAfter(seconds: Int) {
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(
            { takePhoto { } }, seconds.coerceIn(0, 30) * 1000L
        )
    }

    fun stop() {
        try { executor.shutdownNow() } catch (_: Exception) {}
    }
}
