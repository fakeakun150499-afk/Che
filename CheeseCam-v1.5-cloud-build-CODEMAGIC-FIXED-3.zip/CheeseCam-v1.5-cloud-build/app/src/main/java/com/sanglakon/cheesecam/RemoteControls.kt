package com.sanglakon.cheesecam

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun RemoteControls(
    connected: Boolean,
    onCommand: (String) -> Unit
) {
    var timer by remember { mutableStateOf(0) }

    Column(
        Modifier.fillMaxWidth().padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(if (connected) "Terhubung ke Kamera" else "Belum terhubung")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { onCommand(RemoteProtocol.SHUTTER) }) {
                Text("📸 SHUTTER")
            }
            OutlinedButton(onClick = { onCommand(RemoteProtocol.FRONT) }) {
                Text("Depan")
            }
            OutlinedButton(onClick = { onCommand(RemoteProtocol.BACK) }) {
                Text("Belakang")
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { onCommand(RemoteProtocol.FLASH_ON) }) { Text("Flash ON") }
            OutlinedButton(onClick = { onCommand(RemoteProtocol.FLASH_OFF) }) { Text("Flash OFF") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(0, 3, 5, 10).forEach { seconds ->
                FilterChip(
                    selected = timer == seconds,
                    onClick = {
                        timer = seconds
                        onCommand(RemoteProtocol.timer(seconds))
                    },
                    label = { Text(if (seconds == 0) "Instan" else "${seconds}s") }
                )
            }
        }
    }
}
